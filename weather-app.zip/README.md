# Weather App

## Descrição
Aplicação web para consulta de informações climáticas de uma cidade utilizando a API OpenWeatherMap.

## Tecnologias Utilizadas
- HTML
- CSS
- JavaScript

## Como Executar
1. Clone o repositório:
   ```
   git clone https://github.com/seu-usuario/weather-app.git
   ```
2. Navegue até a pasta do projeto:
   ```
   cd weather-app
   ```
3. Abra o arquivo `index.html` em um navegador web.

## Funcionalidades
- Consulta de dados climáticos de uma cidade.
- Exibição de temperatura, umidade e condições do tempo.
- Interface responsiva para dispositivos móveis e desktops.

## Contribuição
Contribuições são bem-vindas! Sinta-se à vontade para enviar um pull request.

## Licença
Este projeto está licenciado sob a licença MIT.
