document.getElementById('weather-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const city = document.getElementById('city').value.trim().replace(' ', '%20');
    const apiKey = '61c9135263f389073e2662214d057fbd';
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=pt_br`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const weatherData = `
                    <p>Temperatura: ${data.main.temp} °C</p>
                    <p>Umidade: ${data.main.humidity} %</p>
                    <p>Condições: ${data.weather[0].description}</p>
                `;
                document.getElementById('weather-data').innerHTML = weatherData;
                document.getElementById('weather-data').style.display = 'block';
            } else {
                alert(`Cidade não encontrada: ${data.message}`);
            }
        })
        .catch(error => {
            console.error('Erro ao buscar dados:', error);
        });
});
